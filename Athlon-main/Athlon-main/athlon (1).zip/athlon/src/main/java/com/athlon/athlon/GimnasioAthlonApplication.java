package com.athlon.athlon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GimnasioAthlonApplication {

	public static void main(String[] args) {
		SpringApplication.run(GimnasioAthlonApplication.class, args);
	}

}
