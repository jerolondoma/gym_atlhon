package com.athlon.athlon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GimnasioAthlonApplicationTests {

	@Test
	void contextLoads() {
	}

}
